package com.dev.makov.rl_system.controller;
import com.dev.makov.rl_system.entity.Absence;
import com.dev.makov.rl_system.entity.StudentGrade;
import com.dev.makov.rl_system.entity.User;
import com.dev.makov.rl_system.service.AbsenceService;
import com.dev.makov.rl_system.service.GradeService;
import com.dev.makov.rl_system.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/parent")
public class ParentController {

    @Autowired
    private UserService userService;
    @Autowired private GradeService gradeService;
    @Autowired private AbsenceService absenceService;

    @GetMapping("/home")
    public String home(Model model) {

        // who’s logged in?
        String email = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getName();
        User parent = userService.findByEmail(email);

        // kids
        List<User> children = userService.findChildrenOfParent(parent.getId());

        // map kid-id → grades / absences
        Map<Long, List<StudentGrade>> gradesMap   = new HashMap<>();
        Map<Long, List<Absence>>      absencesMap = new HashMap<>();

        for (User kid : children) {
            gradesMap.put(kid.getId(),
                    gradeService.findGradesByStudentId(kid.getId()));
            absencesMap.put(kid.getId(),
                    absenceService.findByStudentId(kid.getId()));
        }

        // view-model
        model.addAttribute("firstName",  parent.getFirstName());
        model.addAttribute("lastName",   parent.getLastName());
        model.addAttribute("students",   children);
        model.addAttribute("gradesMap",  gradesMap);
        model.addAttribute("absencesMap",absencesMap);

        return "parent/home-parent";
    }
}
