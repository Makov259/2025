package com.dev.makov.rl_system.controller;

import com.dev.makov.rl_system.entity.User;
import com.dev.makov.rl_system.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AdminController {

    private final UserService userService;

    @Autowired
    public AdminController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/admin/home")
    public String home(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated() || authentication.getPrincipal().equals("anonymousUser")) {
            // 🔥 security is off or user is not logged in — use dummy user
            model.addAttribute("firstName", "Guest");
            model.addAttribute("lastName", "Admin");
        } else {
            String email = authentication.getName();
            User currentUser = userService.findByEmail(email);

            if (currentUser != null) {
                model.addAttribute("firstName", currentUser.getFirstName());
                model.addAttribute("lastName", currentUser.getLastName());
            } else {
                // fallback in case userService didn't find user
                model.addAttribute("firstName", "Unknown");
                model.addAttribute("lastName", "User");
            }
        }

        return "admin/home-admin"; // 🧠 make sure this file exists in templates/admin
    }
}
