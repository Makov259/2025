package com.dev.makov.rl_system.controller;

import com.dev.makov.rl_system.dao.ClassRepository;
import com.dev.makov.rl_system.dao.GradeRepository;
import com.dev.makov.rl_system.dao.SchoolSubjectRepository;
import com.dev.makov.rl_system.entity.*;
import com.dev.makov.rl_system.entity.Class;
import com.dev.makov.rl_system.service.AbsenceService;
import com.dev.makov.rl_system.service.GradeService;
import com.dev.makov.rl_system.service.SchoolService;
import com.dev.makov.rl_system.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Controller
public class SchoolController {

    @Autowired
    private UserService userService;

    @Autowired
    private SchoolService schoolService;

    @Autowired
    private GradeService gradeService;

    @Autowired
    private AbsenceService absenceService;

    @Autowired
    private SchoolSubjectRepository schoolSubjectRepository;

    @Autowired
    private GradeRepository gradeRepository;

    @Autowired
    private ClassRepository classRepository;

    @GetMapping("/admin/addSchool")
    public String showAddSchoolForm(Model model) {
        model.addAttribute("school", new School());
        return "admin/addSchool";
    }

    @PostMapping("/admin/addSchoolProcess")
    public String addSchool(@ModelAttribute("school") School school) {
        userService.addSchool(school);
        return "redirect:/admin/home";
    }

    @GetMapping("/school/list")
    public String showSchools(Model model){
        List<School> schools = schoolService.findAll();
        for (School school : schools) {
            List<User> students = userService.findStudentsBySchool(school.getId());
            school.setStudents(new HashSet<>(students));
        }
        model.addAttribute("schools", schools);
        return "/school/list-schools";
    }

    @GetMapping("/school/addDirector")
    public String showAddDirectorForm(@RequestParam("school_id") Long schoolId, Model model) {
        model.addAttribute("director", new User());
        model.addAttribute("schoolId", schoolId);
        return "director/addDirector";
    }

    @PostMapping("/school/processAddDirector")
    public String processAddDirector(@ModelAttribute("director") User director, @RequestParam("schoolId") Long schoolId) {
        School school = schoolService.findById(schoolId);
        userService.registerDirector(director, school);
        school.setDirector(director);
        schoolService.save(school);
        return "redirect:/school/list";
    }

    @GetMapping("/school/updateDirector")
    public String showUpdateDirectorForm(@RequestParam("director_id") Long directorId, Model model) {
        model.addAttribute("director", userService.findById(directorId));
        return "director/updateDirector";
    }

    @PostMapping("/school/processUpdateDirector")
    public String processUpdateDirector(@ModelAttribute("director") User director) {
        userService.updateDirector(director);
        return "redirect:/school/list";
    }

    @GetMapping("/school/deleteDirector")
    public String deleteDirector(@RequestParam("director_id") Long directorId, @RequestParam("school_id") Long schoolId) {
        if (directorId != 0) {
            userService.deleteDirector(directorId);
            School school = schoolService.findById(schoolId);
            if (school != null) {
                school.setDirector(null);
                schoolService.save(school);
            }
        }
        return "redirect:/school/list";
    }

    @GetMapping("/school/displayDirector")
    public String displayDirector(@RequestParam("director_id") Long directorId, Model model){
        model.addAttribute("director", userService.findById(directorId));
        return "director/displayDirector";
    }

    @GetMapping("/school/updateTeacher")
    public String showUpdateTeacherForm(@RequestParam("teacher_id") Long teacherId,
                                        @RequestParam(value = "school_id", required = false) Long schoolId,
                                        Model model) {
        User teacher = userService.findById(teacherId);
        List<SchoolSubject> subjects = schoolSubjectRepository.findAll();
        model.addAttribute("teacher", teacher);
        model.addAttribute("subjects", subjects);
        model.addAttribute("schoolId", schoolId);
        return "teacher/updateTeacher";
    }

    @GetMapping("/school/addTeacher")
    public String showAddTeacherForm(@RequestParam("school_id") Long schoolId, Model model) {
        model.addAttribute("teacher", new User());
        model.addAttribute("schoolId", schoolId);
        model.addAttribute("subjects", schoolSubjectRepository.findAll());
        model.addAttribute("classes", classRepository.findAll());
        return "teacher/addTeacher"; // ✅ make sure this file exists
    }


    @PostMapping("/school/processAddTeacher")
    public String processAddTeacher(@ModelAttribute("teacher") User teacher,
                                    @RequestParam("schoolId") Long schoolId,
                                    @RequestParam("subjectIds") Set<Long> subjectIds,
                                    @RequestParam("classId") Long classId) {
        School school = schoolService.findById(schoolId);
        Class aClass = classRepository.findById(classId).orElseThrow(() -> new RuntimeException("Class not found"));
        teacher.setSchool(school);
        teacher.setaClass(aClass);
        userService.registerTeacher(teacher, subjectIds);
        return "redirect:/school/list";
    }

    @PostMapping("/school/processUpdateTeacher")
    public String processUpdateTeacher(@ModelAttribute("teacher") User teacher, @RequestParam("subjectIds") Set<Long> subjectIds) {
        userService.updateTeacher(teacher, subjectIds);
        return "redirect:/school/list";
    }

    @GetMapping("/school/displayTeachers")
    public String displayTeachers(@RequestParam("school_id") Long schoolId, Model model) {
        List<User> teachers = userService.findTeachersBySchool(schoolId);
        model.addAttribute("teachers", teachers);
        model.addAttribute("schoolId", schoolId);
        return "teacher/displayTeachers";
    }

    @GetMapping("/school/addGrade")
    public String showAddGradeForm(@RequestParam("student_id") Long studentId, Model model) {
        model.addAttribute("grade", new Grade());
        model.addAttribute("studentId", studentId);
        model.addAttribute("subjects", schoolSubjectRepository.findAll());
        return "grade/addGrade";
    }

    @PostMapping("/school/processAddGrade")
    public String processAddGrade(@RequestParam("grade") int gradeValue, @RequestParam("studentId") Long studentId, @RequestParam("subjectId") Long subjectId) {
        Grade grade = gradeService.findGradeByValue(gradeValue);
        gradeService.addGradeToStudent(grade.getId(), studentId, subjectId);
        return "redirect:/school/displayGrades?student_id=" + studentId;
    }

    @GetMapping("/school/displayGrades")
    public String displayGrades(@RequestParam("student_id") Long studentId, Model model) {
        User student = userService.findById(studentId);
        List<StudentGrade> grades = gradeService.findGradesByStudentId(studentId);
        model.addAttribute("student", student);
        model.addAttribute("grades", grades);
        return "grade/displayGrades";
    }

    @GetMapping("/school/addAbsence")
    public String showAddAbsenceForm(@RequestParam("student_id") Long studentId, Model model) {
        Absence absence = new Absence();
        model.addAttribute("absence", absence);
        model.addAttribute("studentId", studentId);
        return "absences/addAbsences";
    }

    @PostMapping("/school/processAddAbsence")
    public String processAddAbsence(@ModelAttribute("absence") Absence absence, @RequestParam("studentId") Long studentId) {
        User student = userService.findById(studentId);
        absence.setStudent(student);
        absence.setaClass(student.getaClass());
        absenceService.saveAbsence(absence);
        return "redirect:/school/displayAbsences?student_id=" + studentId;
    }

    @GetMapping("/school/displayAbsences")
    public String displayAbsences(@RequestParam("student_id") Long studentId, Model model) {
        List<Absence> absences = absenceService.findByStudentId(studentId);
        User student = userService.findById(studentId);
        model.addAttribute("absences", absences);
        model.addAttribute("student", student);
        model.addAttribute("studentId", studentId);
        return "absences/displayAbsences";
    }

    @GetMapping("/school/deleteTeacher")
    public String deleteTeacher(@RequestParam("school_id") Long schoolId, Model model) {
        // Fetch all teachers for the school
        List<User> teachers = userService.findTeachersBySchool(schoolId);

        model.addAttribute("schoolId", schoolId);
        model.addAttribute("teachers", teachers);

        return "teacher/deleteTeacher"; // 👈 YOU NEED THIS HTML
    }

    @PostMapping("/school/processDeleteTeacher")
    public String processDeleteTeacher(@RequestParam("teacherId") Long teacherId,
                                       @RequestParam("schoolId") Long schoolId) {
        userService.deleteTeacher(teacherId);
        return "redirect:/school/list";
    }


    @GetMapping("/school/addParent")
    public String showAddParentForm(
            @RequestParam(value = "student_id", required = false) Long studentId,
            Model model) {

        model.addAttribute("parent", new User());      // the empty form-backing bean
        model.addAttribute("studentId", studentId);    // preset if it was in the URL
        return "parent/addParent";                     // <-- template you already have
    }

    @PostMapping("/school/processAddParent")
    public String processAddParent(
            @ModelAttribute("parent") User parent,
            @RequestParam("studentId") Long studentId,
            BindingResult bindingResult) {

        if (bindingResult.hasErrors()) {
            return "parent/addParent";
        }

        userService.registerParentWithStudent(parent, studentId);
        return "redirect:/school/list";
    }


}
