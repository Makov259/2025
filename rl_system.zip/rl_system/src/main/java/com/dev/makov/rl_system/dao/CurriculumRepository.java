package com.dev.makov.rl_system.dao;

import com.dev.makov.rl_system.entity.Curriculum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface CurriculumRepository extends JpaRepository<Curriculum, Long> {
    List<Curriculum> findBySchoolClassId(Long classId);



    @Modifying
    @Transactional    // runs in the same tx as your service call
    @Query(value = """
            UPDATE curriculum
            SET teacher_id = NULL
            WHERE teacher_id = :teacherId
            """, nativeQuery = true)
    void removeTeacherFromCurriculum(@Param("teacherId") Long teacherId);
}



