package com.dev.makov.rl_system.controller;
import com.dev.makov.rl_system.entity.User;
import com.dev.makov.rl_system.service.AbsenceService;
import com.dev.makov.rl_system.service.GradeService;
import com.dev.makov.rl_system.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private UserService userService;
    @Autowired private GradeService gradeService;
    @Autowired private AbsenceService absenceService;

    // ===== already there =====
    @GetMapping("/home")
    public String home(Model model) {
        User me = getLoggedUser();
        model.addAttribute("firstName", me.getFirstName());
        model.addAttribute("lastName",  me.getLastName());
        model.addAttribute("studentId", me.getStudentId());
        return "student/home-student";
    }

    // ===== new pages =====
    @GetMapping("/grades")
    public String grades(Model model) {
        User me = getLoggedUser();
        model.addAttribute("grades",
                gradeService.findGradesByStudentId(me.getId()));
        return "student/grades-student";
    }

    @GetMapping("/absences")
    public String absences(Model model) {
        User me = getLoggedUser();
        model.addAttribute("absences",
                absenceService.findByStudentId(me.getId()));
        return "student/absences-student";
    }

    @GetMapping("/subjects")
    public String subjects(Model model) {
        User me = getLoggedUser();
        // if User has a mapped set:
        model.addAttribute("subjects", me.getSchoolSubjects());
        // otherwise make a repo call -> schoolSubjectRepository.findByUserId(me.getId());
        return "student/subjects-student";
    }

    // helper
    private User getLoggedUser() {
        String email = SecurityContextHolder.getContext()
                .getAuthentication()
                .getName();
        return userService.findByEmail(email);
    }
}
