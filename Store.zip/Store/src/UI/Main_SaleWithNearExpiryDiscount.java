package UI;
import entities.*;
import service.*;

import java.time.LocalDate;
import java.util.List;

public class Main_SaleWithNearExpiryDiscount {
    public static void main(String[] args) {
        StoreService storeService = new StoreService("Магазин - Отстъпки");
        ProductService productService = new ProductService();
        CashierService cashierService = new CashierService();
        ReceiptService receiptService = new ReceiptService();

        storeService.loadStore();
        productService.loadProducts();
        cashierService.loadCashiers();
        receiptService.loadReceiptsFromFiles();

        // ================================
        // ✅ PHASE 1: Initialization
        // ================================

/*        Cashier cashier = new Cashier(103, "Петър Костадинов", 1400);
        cashierService.addCashier(cashier);
        storeService.addCashierToStore(cashier);

        Product yogurt = new FoodProduct(5, "Кисело мляко", 1.4, 100, LocalDate.now().plusDays(1));
        yogurt.updateSellingPrice(true); // apply 15% discount

        productService.addProduct(yogurt);
        storeService.addDeliveredProduct(yogurt);

        productService.saveProducts();
        storeService.saveStore();

        System.out.println("🍶 Инициализацията на млякото и касиера е завършена.");*/
        // ================================
        // ✅ PHASE 2: Selling Only
        // ================================
        try {
            Product yogurtFromDb = productService.findProductById(5);
            Cashier cashierFromDb = cashierService.findCashierById(103); // 🔥 FIX

            ReceiptItem item = new ReceiptItem(yogurtFromDb, 20, yogurtFromDb.getSellingPrice());
            List<ReceiptItem> items = List.of(item);

            if (!productService.canSell(items)) {
                System.out.println("❌ Продажбата е прекратена поради недостатъчни количества.");
                return;
            }

            Receipt receipt = new Receipt(11, cashierFromDb, items); // 👈 use the fetched cashier
            receiptService.addReceipt(receipt);

            yogurtFromDb.reduceQuantity(20);
            storeService.addSoldProduct(yogurtFromDb);

            productService.saveProducts();
            storeService.saveStore();

            System.out.println("✅ Тест Отстъпка:\n" + receipt);
            System.out.println("📈 Приходи: " + receiptService.getTotalRevenue());
            System.out.println("💰 Печалба: " + storeService.calculateProfit());

        } catch (Exception e) {
            System.out.println("⚠️ Грешка при продажбата с отстъпка: " + e.getMessage());
        }

    }
}
