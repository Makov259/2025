package UI;

import entities.*;
import service.*;

import java.time.LocalDate;
import java.util.List;

public class Main_NormalSaleWith2ProductsNoDiscount {
    public static void main(String[] args) {
        StoreService storeService = new StoreService("Тест Магазин 1");
        ProductService productService = new ProductService();
        CashierService cashierService = new CashierService();
        ReceiptService receiptService = new ReceiptService();

        storeService.loadStore();
        productService.loadProducts();
        cashierService.loadCashiers();
        receiptService.loadReceiptsFromFiles();

        // =========================
        // ✅ PHASE 1: Initialization
        // =========================
   /*     Cashier cashier = new Cashier(102, "Мария Георгиева", 1300);
        cashierService.addCashier(cashier);
        storeService.addCashierToStore(cashier);

        Product eggs = new FoodProduct(3, "Яйца", 2.5, 2000, LocalDate.now().plusDays(5));
        Product flour = new NonFoodProduct(4, "ръкавици", 1.2, 4000, null);
        Product laptop = new NonFoodProduct(10, "Laptop", 2000, 10, null);
        eggs.updateSellingPrice(false);
        flour.updateSellingPrice(false);
        laptop.updateSellingPrice(false);

        productService.addProduct(eggs);
        productService.addProduct(flour);
        productService.addProduct(laptop);
        storeService.addDeliveredProduct(eggs);
        storeService.addDeliveredProduct(flour);
        storeService.addDeliveredProduct(laptop);

        productService.saveProducts();
        storeService.saveStore();

        System.out.println("📦 Инициализация на продукти и магазин завършена.");*/

        // =========================
        // ✅ PHASE 2: Sell Only Mode
        // =========================
        try {
            Product eggs = productService.findProductById(3);
            Product flour = productService.findProductById(4);
            Product laptop = productService.findProductById(10);

            Cashier cashier = new Cashier(102, "Марияна Пехливанова", 1300);
            storeService.addCashierToStore(cashier); // safe even if re-added

            ReceiptItem i1 = new ReceiptItem(eggs, 10, eggs.getSellingPrice());
            ReceiptItem i2 = new ReceiptItem(flour, 5, flour.getSellingPrice());
            ReceiptItem i3 = new ReceiptItem(laptop, 10, laptop.getSellingPrice());

            List<ReceiptItem> items = List.of(i1, i2, i3);

            // ✅ Validate if we have enough quantity before proceeding
            if (!productService.canSell(items)) {
                System.out.println("❌ Продажбата е прекратена поради недостатъчни количества.");
                return;
            }

            Receipt receipt = new Receipt(9, cashier, items);
            receiptService.addReceipt(receipt);

            // ✅ Safe to reduce quantities now
            eggs.reduceQuantity(10);
            flour.reduceQuantity(5);
            laptop.reduceQuantity(10);

            storeService.addSoldProduct(eggs);
            storeService.addSoldProduct(flour);
            storeService.addSoldProduct(laptop);

            productService.saveProducts();
            storeService.saveStore();

            double profit = storeService.calculateProfit(); // 💰 calculate
            storeService.saveProfitToFile(profit);          // 🧾 write to txt file

            System.out.println("✅ Тест Продажба:\n" + receipt);
            System.out.println("📈 Приходи: " + receiptService.getTotalRevenue());
            System.out.println("💰 Печалба: " + storeService.calculateProfit());

        } catch (Exception e) {
            System.out.println("⚠️ Грешка при продажба: " + e.getMessage());
        }


    }
}
