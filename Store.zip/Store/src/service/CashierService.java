package service;

import entities.Cashier;
import exceptions.CashierNotFoundException;

import java.io.*;
import java.util.*;

public class CashierService {
    private final Map<Integer, Cashier> cashierMap = new HashMap<>();
    private final String filePath = "cashiers.dat";

    public void addCashier(Cashier cashier) {
        cashierMap.put(cashier.getId(), cashier);
        saveCashiers();
    }

    public Cashier findCashierById(int id) {
        Cashier cashier = cashierMap.get(id);
        if (cashier == null) {
            throw new CashierNotFoundException("Касиер с ID " + id + " не е намерен.");
        }
        return cashier;
    }

    public List<Cashier> getAllCashiers() {
        return new ArrayList<>(cashierMap.values());
    }

    public double calculateTotalSalaries() {
        return cashierMap.values()
                .stream()
                .mapToDouble(Cashier::getMonthlySalary)
                .sum();
    }

    public void loadCashiers() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            List<Cashier> loaded = (List<Cashier>) ois.readObject();
            cashierMap.clear();
            for (Cashier c : loaded) {
                cashierMap.put(c.getId(), c);
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Грешка при зареждане на касиери: " + e.getMessage());
        }
    }

    public void saveCashiers() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(new ArrayList<>(cashierMap.values()));
        } catch (IOException e) {
            System.out.println("Грешка при запазване на касиери: " + e.getMessage());
        }
    }
}
