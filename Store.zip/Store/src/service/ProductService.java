package service;

import entities.Product;
import entities.ReceiptItem;
import exceptions.ProductNotFoundException;

import java.io.*;
import java.util.*;

public class ProductService {
    private final Map<Integer, Product> productMap = new HashMap<>();
    private final String filePath = "products.dat";
    private final String allProductsTxtPath = "all_products.txt";


    public void addProduct(Product product) {
        productMap.put(product.getId(), product);
        saveProducts();
    }

    public Product findProductById(int id) {
        Product product = productMap.get(id);
        if (product == null) {
            throw new ProductNotFoundException("Продукт с ID " + id + " не е намерен.");
        }
        return product;
    }

    public List<Product> getAllProducts() {
        return new ArrayList<>(productMap.values());
    }

    public void loadProducts() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            List<Product> loadedProducts = (List<Product>) ois.readObject();
            productMap.clear();
            for (Product p : loadedProducts) {
                productMap.put(p.getId(), p);
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Няма налични продукти за зареждане или файлът е празен.");
        }
    }


    public void saveProducts() {
        List<Product> productList = new ArrayList<>(productMap.values());

        // Save to binary file
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(productList);
        } catch (IOException e) {
            System.out.println("Грешка при запис на продуктите: " + e.getMessage());
        }

        // Save to readable text file
        try (PrintWriter writer = new PrintWriter(new FileWriter(allProductsTxtPath))) {
            for (Product product : productList) {
                writer.println(formatProduct(product));
            }
        } catch (IOException e) {
            System.out.println("⚠️ Грешка при запис на all_products.txt: " + e.getMessage());
        }
    }


    public void updateSellingPrices(int nearExpiryThreshold, double expiryDiscountPercentage) {
        for (Product product : productMap.values()) {
            boolean isNearExpiry = product.isNearExpiry(nearExpiryThreshold);
            product.updateSellingPrice(isNearExpiry);
        }
    }

    public void reduceProductQuantity(int productId, int quantityToReduce) {
        Product product = findProductById(productId);
        product.reduceQuantity(quantityToReduce);
        saveProducts();
    }

    public boolean canSell(List<ReceiptItem> items) {
        boolean allOk = true;

        for (ReceiptItem item : items) {
            if (item.getProduct().getQuantity() < item.getQuantity()) {
                System.out.println("❌ Недостатъчно количество за продукт: " + item.getProduct().getName());
                allOk = false;
            }
        }

        return allOk;
    }

    private String formatProduct(Product product) {
        return String.format(
                "ID: %d | Име: %s | Доставка: %.2f | Кол-во: %d | Годност: %s | Продажна: %.2f | Категория: %s",
                product.getId(),
                product.getName(),
                product.getDeliveryPrice(),
                product.getQuantity(),
                product.getExpirationDate() != null ? product.getExpirationDate().toString() : "N/A",
                product.getSellingPrice(),
                product.getCategory()
        );
    }


}
