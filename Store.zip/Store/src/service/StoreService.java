package service;

import entities.Store;

import java.io.*;

public class StoreService {
    private Store store;
    private final String filePath = "store.dat";

    public StoreService(String storeName) {
        this.store = new Store(storeName);
    }

    public Store getStore() {
        return store;
    }

    public void addCashierToStore(entities.Cashier cashier) {
        store.addCashier(cashier);
    }

    public void addDeliveredProduct(entities.Product product) {
        store.addDeliveredProduct(product);
    }

    public void addSoldProduct(entities.Product product) {
        store.addSoldProduct(product);
    }

    public double calculateProfit() {
        return store.getProfit();
    }

    public void saveStore() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(store);
        } catch (IOException e) {
            System.out.println("⚠️ Неуспешно запазване на магазина: " + e.getMessage());
        }
    }

    public void loadStore() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            store = (Store) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("⚠️ Неуспешно зареждане на магазина: " + e.getMessage());
        }
    }
    public void saveProfitToFile(double profit) {
        String filePath = "total_profit.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(String.format("💰 Общата печалба до момента е: %.2f лв", profit));
        } catch (IOException e) {
            System.out.println("⚠️ Грешка при запис на печалбата: " + e.getMessage());
        }
    }

}
