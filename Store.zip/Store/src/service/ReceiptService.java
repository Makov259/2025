package service;

import entities.Receipt;

import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ReceiptService {
    private final List<Receipt> receipts = new ArrayList<>();
    private final String folderPath = "receipts"; // Folder for .txt files

    public ReceiptService() {
        File folder = new File(folderPath);
        if (!folder.exists()) {
            folder.mkdirs();
        }
    }

    public void addReceipt(Receipt receipt) {
        receipts.add(receipt);
        saveReceiptToFile(receipt);
    }

    public List<Receipt> getAllReceipts() {
        return new ArrayList<>(receipts);
    }

    public int getTotalReceiptsCount() {
        return receipts.size();
    }

    public double getTotalRevenue() {
        return receipts.stream()
                .mapToDouble(Receipt::getTotalAmount)
                .sum();
    }

    private void saveReceiptToFile(Receipt receipt) {
        String filename = folderPath + "/receipt_" + receipt.getReceiptNumber() + ".txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            writer.write(receipt.toString());
        } catch (IOException e) {
            System.out.println("Грешка при запис на касова бележка: " + e.getMessage());
        }
    }

    public void loadReceiptsFromFiles() {
        File folder = new File(folderPath);
        File[] files = folder.listFiles((dir, name) -> name.endsWith(".txt"));
        if (files == null) return;

        for (File file : files) {
            System.out.println("Съдържание на: " + file.getName());
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                reader.lines().forEach(System.out::println);
            } catch (IOException e) {
                System.out.println("Грешка при четене: " + file.getName());
            }
        }
    }
}
