import entities.FoodProduct;
import entities.Product;
import org.junit.Test;
import service.ProductService;

import java.time.LocalDate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@Test
public void testAddAndSaveProduct() {
    ProductService ps = new ProductService();

    Product testProduct = new FoodProduct(100, "Test Yogurt", 1.2, 100, LocalDate.now().plusDays(10));
    testProduct.updateSellingPrice(false);

    ps.addProduct(testProduct);

    Product loadedProduct = ps.findProductById(100);
    assertNotNull(loadedProduct);
    assertEquals("Test Yogurt", loadedProduct.getName());
    assertEquals(100, loadedProduct.getQuantity());
}

public void main() {
}
