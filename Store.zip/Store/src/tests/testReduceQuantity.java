import entities.NonFoodProduct;
import entities.Product;
import org.junit.Test;
import service.ProductService;

import static org.junit.Assert.assertEquals;

@Test
public void testReduceQuantity() {
    ProductService ps = new ProductService();

    Product testProduct = new NonFoodProduct(101, "Test Laptop", 1000, 50, null);
    testProduct.updateSellingPrice(false);

    ps.addProduct(testProduct);
    ps.reduceProductQuantity(101, 10);

    Product loaded = ps.findProductById(101);
    assertEquals(40, loaded.getQuantity());
}

public void main() {
}
