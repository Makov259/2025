package entities;

public class FoodProduct extends Product {
    private static final double MARKUP_PERCENTAGE = 60.0;

    public FoodProduct(int id, String name, double unitCost, int quantity, java.time.LocalDate expirationDate) {
        super(id, name, unitCost, quantity, expirationDate);
    }

    @Override
    public double getMarkupPercentage() {
        return MARKUP_PERCENTAGE;
    }

    @Override
    public String getCategory() {
        return "Хранителна";
    }
}
