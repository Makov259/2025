package entities;
import java.io.Serializable;

public class Cashier implements Serializable {

    //Data
    private final int id;
    private String name;
    private double monthlySalary;

    //Constructor
    public Cashier(int id, String name, double monthlySalary) {
        this.id = id;
        this.name = name;
        this.monthlySalary = monthlySalary;
    }

    // --- Getters ---
    public int getId() { return id; }
    public String getName() { return name; }
    public double getMonthlySalary() { return monthlySalary; }

    // --- Setters ---
    public void setName(String name) { this.name = name; }
    public void setMonthlySalary(double monthlySalary) { this.monthlySalary = monthlySalary; }

    @Override
    public String toString() {
        return "Касиер ID: " + id +
                " | Име: " + name +
                " | Месечна заплата: " + monthlySalary + " лв";
    }
}
