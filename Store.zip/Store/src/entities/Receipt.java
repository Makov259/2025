package entities;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Receipt implements Serializable {

    //Data
    private final int receiptNumber;
    private final Cashier cashier;
    private final LocalDateTime timestamp;
    private final List<ReceiptItem> items;
    private final double totalAmount;

    //Constructor
    public Receipt(int receiptNumber, Cashier cashier, List<ReceiptItem> items) {
        this.receiptNumber = receiptNumber;
        this.cashier = cashier;
        this.timestamp = LocalDateTime.now();
        this.items = new ArrayList<>(items);
        this.totalAmount = calculateTotal();
    }

    //Custom Methods
    private double calculateTotal() {
        return items.stream()
                .mapToDouble(ReceiptItem::getTotalPrice)
                .sum();
    }

    //Getters & Setters
    public int getReceiptNumber() {
        return receiptNumber;
    }
    public Cashier getCashier() {
        return cashier;
    }
    public LocalDateTime getTimestamp() {
        return timestamp;
    }
    public List<ReceiptItem> getItems() {
        return new ArrayList<>(items);
    }
    public double getTotalAmount() {
        return totalAmount;
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("КАСОВА БЕЛЕЖКА №").append(receiptNumber).append("\n");
        sb.append("Касиер: ").append(cashier.getName()).append(" | ID: ").append(cashier.getId()).append("\n");
        sb.append("Дата/Час: ").append(timestamp).append("\n");
        sb.append("Списък със стоки:\n");
        for (ReceiptItem item : items) {
            sb.append("  - ").append(item).append("\n");
        }
        sb.append("Обща сума: ").append(totalAmount).append(" лв\n");
        return sb.toString();
    }
}
