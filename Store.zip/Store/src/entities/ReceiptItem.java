package entities;

import java.io.Serializable;

public class ReceiptItem implements Serializable {

    //Data
    private final Product product;
    private final int quantity;
    private final double pricePerUnit; // price at the time of purchase

    //Constructor
    public ReceiptItem(Product product, int quantity, double pricePerUnit) {
        this.product = product;
        this.quantity = quantity;
        this.pricePerUnit = pricePerUnit;
    }

    //Getters & Setters
    public Product getProduct() {
        return product;
    }
    public int getQuantity() {
        return quantity;
    }
    public double getPricePerUnit() {
        return pricePerUnit;
    }
    public double getTotalPrice() {
        return pricePerUnit * quantity;
    }
    @Override
    public String toString() {
        return product.getName() +
                " | Цена: " + pricePerUnit +
                " | Кол-во: " + quantity +
                " | Общо: " + getTotalPrice();
    }
}
