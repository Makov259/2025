package entities;

import java.io.Serializable;
import java.time.LocalDate;

public abstract class Product implements Serializable {

    //Data
    private final int id;
    private String name;
    private double deliveryPrice; // price paid by store
    private int quantity;
    private LocalDate expirationDate;
    private double sellingPrice;


    //Constructor
    public Product(int id, String name, double deliveryPrice, int quantity, LocalDate expirationDate) {
        this.id = id;
        this.name = name;
        this.deliveryPrice = deliveryPrice;
        this.quantity = quantity;
        this.expirationDate = expirationDate;
    }

    // --- Abstracts ---
    public abstract double getMarkupPercentage(); // хранилни/нехранителни
    public abstract String getCategory(); // just for display

    // --- Selling price logic ---
    public void updateSellingPrice(boolean isNearExpiry) {
        double expiryDiscountPercentage = 5;
        double basePrice = deliveryPrice + (deliveryPrice * getMarkupPercentage() / 100);
        if (isNearExpiry) {
            basePrice -= basePrice * (expiryDiscountPercentage  / 100);
        }
        this.sellingPrice = basePrice;
    }

    public boolean isExpired() {
        return expirationDate != null && expirationDate.isBefore(LocalDate.now());
    }

    public boolean isNearExpiry(int thresholdDays) {
        return expirationDate != null &&
                !isExpired() &&
                expirationDate.minusDays(thresholdDays).isBefore(LocalDate.now());
    }

    public void reduceQuantity(int amount) {
        if (amount > quantity) {
            throw new IllegalArgumentException("Недостатъчно количество от продукта.");
        }
        quantity -= amount;
    }

    // --- Getters/Setters ---
    public int getId() { return id; }
    public String getName() { return name; }
    public double getDeliveryPrice() { return deliveryPrice; }
    public double getSellingPrice() { return sellingPrice; }
    public int getQuantity() { return quantity; }
    public LocalDate getExpirationDate() { return expirationDate; }

    public void setName(String name) { this.name = name; }
    public void setDeliveryPrice(double deliveryPrice) { this.deliveryPrice = deliveryPrice; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setExpirationDate(LocalDate expirationDate) { this.expirationDate = expirationDate; }
    public void setSellingPrice(double sellingPrice) { this.sellingPrice = sellingPrice; }

    @Override
    public String toString() {
        return "ID: " + id +
                " | Име: " + name +
                " | Категория: " + getCategory() +
                " | Доставна цена: " + deliveryPrice +
                " | Продажна цена: " + sellingPrice +
                " | Налично: " + quantity +
                " | Годност до: " + expirationDate;
    }
}
