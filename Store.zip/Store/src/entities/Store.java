package entities;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Store implements Serializable {

    //Data
    private final String name;
    private final List<Cashier> cashiers;
    private final List<Product> deliveredProducts;
    private final List<Product> soldProducts;

    //Constructor
    public Store(String name) {
        this.name = name;
        this.cashiers = new ArrayList<>();
        this.deliveredProducts = new ArrayList<>();
        this.soldProducts = new ArrayList<>();
    }

    //Getters&Setters
    public String getName() {
        return name;
    }
    public List<Cashier> getCashiers() {
        return cashiers;
    }
    public List<Product> getDeliveredProducts() {
        return deliveredProducts;
    }
    public List<Product> getSoldProducts() {
        return soldProducts;
    }
    public void addCashier(Cashier cashier) {
        cashiers.add(cashier);
    }
    public void addDeliveredProduct(Product product) {
        deliveredProducts.add(product);
    }
    public void addSoldProduct(Product product) {
        soldProducts.add(product);
    }
    public double getTotalSalaries() {
        return cashiers.stream().mapToDouble(Cashier::getMonthlySalary).sum();
    }

    public double getTotalRevenue() {
        return soldProducts.stream()
                .mapToDouble(p -> p.getSellingPrice() * p.getQuantity())
                .sum();
    }

    public double getProfit() {
        double cost = soldProducts.stream()
                .mapToDouble(p -> p.getDeliveryPrice() * p.getQuantity())
                .sum();
        return getTotalRevenue() - cost - getTotalSalaries();
    }

    @Override
    public String toString() {
        return "Магазин: " + name +
                "\nКасиери: " + cashiers.size() +
                "\nДоставени стоки: " + deliveredProducts.size() +
                "\nПродадени стоки: " + soldProducts.size();
    }
}
