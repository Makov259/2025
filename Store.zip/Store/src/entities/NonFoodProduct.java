package entities;

public class NonFoodProduct extends Product {
    private static final double MARKUP_PERCENTAGE = 70.0;

    public NonFoodProduct(int id, String name, double unitCost, int quantity, java.time.LocalDate expirationDate) {
        super(id, name, unitCost, quantity, expirationDate);
    }

    @Override
    public double getMarkupPercentage() {
        return MARKUP_PERCENTAGE;
    }

    @Override
    public String getCategory() {
        return "Нехранителна";
    }
}
